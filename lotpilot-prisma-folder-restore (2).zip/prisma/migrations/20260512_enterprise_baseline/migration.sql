-- LotPilot enterprise baseline migration
-- Generated manually from prisma/schema.prisma because Prisma engine download was unavailable in this environment.
-- Apply in a non-production environment first, validate, then promote with `npx prisma migrate deploy`.

-- CreateEnum
CREATE TYPE "SourceSystem" AS ENUM ('VINSOLUTIONS', 'AUTOMOTIVE_MASTERMIND', 'AFFINITIV', 'MANUAL', 'OTHER');

CREATE TYPE "LeadStage" AS ENUM ('NEW', 'NEEDS_APPOINTMENT_ASK', 'TENTATIVE', 'CONFIRMED', 'ARRIVING_TODAY', 'MISSED_RESCUE', 'SHOWN', 'SOLD', 'LOST');

CREATE TYPE "OwnershipState" AS ENUM ('AI_OWNED', 'REP_OWNED', 'DESK_SUPPORT', 'MANAGER_NOW');

CREATE TYPE "LeadStatus" AS ENUM ('ACTIVE', 'PARKED', 'CLOSED');

CREATE TYPE "ConversationChannel" AS ENUM ('SMS', 'EMAIL', 'CALL', 'INTERNAL', 'OTHER');

CREATE TYPE "MessageDirection" AS ENUM ('INBOUND', 'OUTBOUND', 'INTERNAL');

CREATE TYPE "MessageStatus" AS ENUM ('DRAFT', 'QUEUED', 'SENT', 'DELIVERED', 'FAILED', 'RECEIVED');

CREATE TYPE "TaskStatus" AS ENUM ('OPEN', 'IN_PROGRESS', 'DONE', 'CANCELED');

CREATE TYPE "CaptureAction" AS ENUM ('CREATED', 'UPDATED', 'MERGED', 'NOOP');

CREATE TYPE "DedupeStrategy" AS ENUM ('SOURCE_RECORD_ID', 'PHONE', 'EMAIL', 'SAFE_FALLBACK', 'NONE');

CREATE TYPE "ReplyClassification" AS ENUM ('POSITIVE_INTEREST', 'APPOINTMENT_READY', 'NEEDS_NUMBERS', 'TRADE_QUESTION', 'PAYMENT_OBJECTION', 'NOT_INTERESTED', 'STOP', 'NEEDS_HUMAN', 'UNKNOWN');

CREATE TYPE "AIDraftIntent" AS ENUM ('FIRST_RESPONSE', 'FOLLOW_UP', 'APPOINTMENT_ASK', 'FIRM_UP_APPOINTMENT', 'CONFIRM_APPOINTMENT', 'ARRIVING_TODAY_CHECK', 'MISSED_APPOINTMENT_RESCUE', 'REACTIVATION');

CREATE TYPE "AIDecisionUrgency" AS ENUM ('LOW', 'MEDIUM', 'HIGH');

CREATE TYPE "AutomationStatus" AS ENUM ('ACTIVE', 'PAUSED', 'STOPPED', 'HANDOFF');

CREATE TYPE "WorkflowMode" AS ENUM ('NEW_LEAD', 'APPOINTMENT_ACTIVE', 'SERVICE_WHILE_HERE', 'SERVICE_APPOINTMENT_FIRST', 'MINING_REACTIVATION', 'MISSED_RESCUE', 'HUMAN_HANDOFF');

CREATE TYPE "ProspectListType" AS ENUM ('HIGH_APR', 'HIGH_MILEAGE_LEASE', 'LEASE_MATURITY', 'SERVICE_APPRAISAL', 'PAYMENT_PAIN', 'MISSED_RESCUES', 'HOT_REPLIES', 'CUSTOM');

CREATE TYPE "LanguageCode" AS ENUM ('EN', 'ES');

CREATE TYPE "AgentAutomationMode" AS ENUM ('OFF', 'SUGGEST_ONLY', 'MANUAL_SEND', 'SEMI_AUTO');

CREATE TYPE "AutoResponseMode" AS ENUM ('OFF', 'SUGGEST_ONLY', 'MANUAL_SEND', 'SEMI_AUTO', 'SAFE_AUTO');

CREATE TYPE "AutoResponseStatus" AS ENUM ('PENDING_REVIEW', 'ELIGIBLE', 'DEFERRED', 'AUTO_RESPONDED', 'ESCALATED', 'BLOCKED');

CREATE TYPE "PersonalizationSignalType" AS ENUM ('DRAFT_SENT_AS_IS', 'DRAFT_EDITED_BEFORE_SEND', 'DRAFT_IGNORED', 'MANUAL_MESSAGE_REPLACED_AI', 'COMMAND_USED', 'WORKFLOW_TOGGLE_CHANGED', 'HANDOFF_USED', 'ESCALATION_USED', 'LANGUAGE_OVERRIDE');

CREATE TYPE "WorkflowJobType" AS ENUM ('FOLLOW_UP_DUE', 'APPOINTMENT_FIRM_UP', 'CONFIRMATION_REMINDER', 'ARRIVING_TODAY_CHECK', 'MISSED_APPOINTMENT_RESCUE', 'REP_ALERT_TASK', 'SERVICE_DRIVE_ACTION', 'MINING_REACTIVATION');

CREATE TYPE "WorkflowJobStatus" AS ENUM ('SCHEDULED', 'RUNNING', 'COMPLETED', 'SKIPPED', 'FAILED', 'CANCELED');

CREATE TYPE "TaskType" AS ENUM ('GENERAL', 'FOLLOW_UP', 'HOT_HANDOFF', 'URGENT_REPLY', 'APPOINTMENT_REVIEW', 'RESCUE', 'SERVICE_OPPORTUNITY', 'REACTIVATION', 'DESK_SUPPORT', 'CALL_REVIEW');

CREATE TABLE "User" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "name" TEXT,
    "passwordHash" TEXT,
    "role" TEXT NOT NULL DEFAULT 'admin',
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "AuthAuditEvent" (
    "id" TEXT NOT NULL,
    "userId" TEXT,
    "email" TEXT,
    "action" TEXT NOT NULL,
    "success" BOOLEAN NOT NULL DEFAULT false,
    "ipAddress" TEXT,
    "userAgent" TEXT,
    "detail" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AuthAuditEvent_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "LoginThrottle" (
    "id" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "scope" TEXT NOT NULL,
    "email" TEXT,
    "ipAddress" TEXT,
    "attemptCount" INTEGER NOT NULL DEFAULT 0,
    "windowStartedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "blockedUntil" TIMESTAMP(3),
    "lastAttemptAt" TIMESTAMP(3),
    "userId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "LoginThrottle_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "Person" (
    "id" TEXT NOT NULL,
    "firstName" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "fullName" TEXT NOT NULL,
    "email" TEXT,
    "emailNormalized" TEXT,
    "phone" TEXT,
    "phoneNormalized" TEXT,
    "city" TEXT,
    "state" TEXT,
    "postalCode" TEXT,
    "notes" TEXT,
    "preferredLanguage" "LanguageCode",
    "detectedLanguage" "LanguageCode",
    "languageConfidence" DOUBLE PRECISION,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "Person_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "Lead" (
    "id" TEXT NOT NULL,
    "externalId" TEXT,
    "sourceSystem" "SourceSystem" NOT NULL DEFAULT 'MANUAL',
    "sourceName" TEXT,
    "stage" "LeadStage" NOT NULL DEFAULT 'NEW',
    "ownershipState" "OwnershipState" NOT NULL DEFAULT 'AI_OWNED',
    "status" "LeadStatus" NOT NULL DEFAULT 'ACTIVE',
    "vehicleInterest" TEXT,
    "lastContactAt" TIMESTAMP(3),
    "nextActionAt" TIMESTAMP(3),
    "notes" TEXT,
    "preferredLanguage" "LanguageCode",
    "workflowMode" "WorkflowMode" NOT NULL DEFAULT 'NEW_LEAD',
    "workflowModeReason" TEXT,
    "automationStatus" "AutomationStatus" NOT NULL DEFAULT 'ACTIVE',
    "automationPausedAt" TIMESTAMP(3),
    "automationPauseReason" TEXT,
    "nextFollowUpAt" TIMESTAMP(3),
    "automationLastRunAt" TIMESTAMP(3),
    "lastAutoResponseAt" TIMESTAMP(3),
    "callPriorityScore" INTEGER NOT NULL DEFAULT 0,
    "callPriorityReason" TEXT,
    "lastCallGuidanceAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "personId" TEXT NOT NULL,
    "ownerUserId" TEXT,
    CONSTRAINT "Lead_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "LeadSource" (
    "id" TEXT NOT NULL,
    "leadId" TEXT NOT NULL,
    "personId" TEXT NOT NULL,
    "sourceSystem" "SourceSystem" NOT NULL,
    "sourceName" TEXT,
    "sourceRecordId" TEXT,
    "sourceCustomerId" TEXT,
    "sourceUrl" TEXT,
    "externalUpdatedAt" TIMESTAMP(3),
    "rawPayload" JSONB,
    "normalizedPayload" JSONB,
    "firstCapturedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastCapturedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "captureCount" INTEGER NOT NULL DEFAULT 1,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "LeadSource_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "AgentProfile" (
    "id" TEXT NOT NULL,
    "agentName" TEXT NOT NULL DEFAULT 'LotPilot',
    "assistantLabel" TEXT NOT NULL DEFAULT 'BDC Agent',
    "agentPersona" TEXT DEFAULT 'Helpful, concise dealership BDC assistant',
    "defaultLanguage" "LanguageCode" NOT NULL DEFAULT 'EN',
    "supportedLanguages" "LanguageCode"[] NOT NULL DEFAULT ARRAY['EN', 'ES']::"LanguageCode"[],
    "workDays" INTEGER[] NOT NULL DEFAULT ARRAY[1, 2, 3, 4, 5, 6],
    "workHoursStart" TEXT NOT NULL DEFAULT '08:30',
    "workHoursEnd" TEXT NOT NULL DEFAULT '18:00',
    "storeHoursStart" TEXT NOT NULL DEFAULT '08:00',
    "storeHoursEnd" TEXT NOT NULL DEFAULT '20:00',
    "contactWindowStart" TEXT NOT NULL DEFAULT '09:00',
    "contactWindowEnd" TEXT NOT NULL DEFAULT '19:00',
    "timezone" TEXT NOT NULL DEFAULT 'America/New_York',
    "automationMode" "AgentAutomationMode" NOT NULL DEFAULT 'SUGGEST_ONLY',
    "autoResponseMode" "AutoResponseMode" NOT NULL DEFAULT 'SUGGEST_ONLY',
    "allowNewLeads" BOOLEAN NOT NULL DEFAULT true,
    "allowAppointments" BOOLEAN NOT NULL DEFAULT true,
    "allowMissedRescue" BOOLEAN NOT NULL DEFAULT true,
    "allowService" BOOLEAN NOT NULL DEFAULT true,
    "allowMining" BOOLEAN NOT NULL DEFAULT true,
    "allowSms" BOOLEAN NOT NULL DEFAULT true,
    "allowEmail" BOOLEAN NOT NULL DEFAULT true,
    "allowSafeAutoSms" BOOLEAN NOT NULL DEFAULT false,
    "allowSafeAutoEmail" BOOLEAN NOT NULL DEFAULT false,
    "allowSafeAutoNewLeads" BOOLEAN NOT NULL DEFAULT false,
    "allowSafeAutoAppointments" BOOLEAN NOT NULL DEFAULT false,
    "allowSafeAutoMissedRescue" BOOLEAN NOT NULL DEFAULT false,
    "allowSafeAutoService" BOOLEAN NOT NULL DEFAULT false,
    "allowSafeAutoMining" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "AgentProfile_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "SmartFilter" (
    "id" TEXT NOT NULL,
    "agentProfileId" TEXT NOT NULL,
    "key" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "commandText" TEXT NOT NULL,
    "listType" "ProspectListType" NOT NULL,
    "sourceSystems" "SourceSystem"[] NOT NULL,
    "workflowModes" "WorkflowMode"[] NOT NULL,
    "isPinned" BOOLEAN NOT NULL DEFAULT true,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "SmartFilter_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "AgentCommand" (
    "id" TEXT NOT NULL,
    "agentProfileId" TEXT NOT NULL,
    "leadId" TEXT,
    "actorUserId" TEXT,
    "commandText" TEXT NOT NULL,
    "commandKey" TEXT NOT NULL,
    "resultSummary" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AgentCommand_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "WorkflowJobLog" (
    "id" TEXT NOT NULL,
    "dedupeKey" TEXT,
    "queueName" TEXT NOT NULL,
    "jobId" TEXT,
    "leadId" TEXT,
    "appointmentId" TEXT,
    "conversationId" TEXT,
    "taskId" TEXT,
    "jobType" "WorkflowJobType" NOT NULL,
    "status" "WorkflowJobStatus" NOT NULL DEFAULT 'SCHEDULED',
    "scheduledFor" TIMESTAMP(3),
    "startedAt" TIMESTAMP(3),
    "finishedAt" TIMESTAMP(3),
    "attempt" INTEGER NOT NULL DEFAULT 0,
    "lastError" TEXT,
    "payload" JSONB,
    "result" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "WorkflowJobLog_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "CaptureAudit" (
    "id" TEXT NOT NULL,
    "leadId" TEXT,
    "personId" TEXT,
    "leadSourceId" TEXT,
    "sourceSystem" "SourceSystem" NOT NULL,
    "sourceName" TEXT,
    "sourceRecordId" TEXT,
    "action" "CaptureAction" NOT NULL,
    "dedupeStrategy" "DedupeStrategy" NOT NULL DEFAULT 'NONE',
    "requestId" TEXT,
    "payload" JSONB,
    "normalizedPayload" JSONB,
    "resultSummary" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "CaptureAudit_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "Conversation" (
    "id" TEXT NOT NULL,
    "leadId" TEXT,
    "personId" TEXT NOT NULL,
    "channel" "ConversationChannel" NOT NULL,
    "provider" TEXT,
    "providerThreadId" TEXT,
    "threadKey" TEXT,
    "subject" TEXT,
    "subjectNormalized" TEXT,
    "isOpen" BOOLEAN NOT NULL DEFAULT true,
    "contactPhone" TEXT,
    "contactPhoneNormalized" TEXT,
    "providerPhone" TEXT,
    "providerPhoneNormalized" TEXT,
    "contactEmail" TEXT,
    "contactEmailNormalized" TEXT,
    "providerEmail" TEXT,
    "unreadCount" INTEGER NOT NULL DEFAULT 0,
    "lastMessageAt" TIMESTAMP(3),
    "lastMessagePreview" TEXT,
    "autoResponseStatus" "AutoResponseStatus" NOT NULL DEFAULT 'PENDING_REVIEW',
    "autoResponseEligible" BOOLEAN NOT NULL DEFAULT false,
    "autoResponseReason" TEXT,
    "autoResponseLastEvaluatedAt" TIMESTAMP(3),
    "lastAutoResponseAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "Conversation_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "Message" (
    "id" TEXT NOT NULL,
    "conversationId" TEXT NOT NULL,
    "direction" "MessageDirection" NOT NULL,
    "status" "MessageStatus" NOT NULL DEFAULT 'DRAFT',
    "subject" TEXT,
    "body" TEXT NOT NULL,
    "externalId" TEXT,
    "provider" TEXT,
    "providerStatus" TEXT,
    "fromPhone" TEXT,
    "toPhone" TEXT,
    "fromEmail" TEXT,
    "toEmail" TEXT,
    "replyToEmail" TEXT,
    "inReplyTo" TEXT,
    "referenceIds" TEXT,
    "language" "LanguageCode",
    "draftSource" TEXT,
    "autoGenerated" BOOLEAN NOT NULL DEFAULT false,
    "errorCode" TEXT,
    "errorMessage" TEXT,
    "rawPayload" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "sentAt" TIMESTAMP(3),
    "receivedAt" TIMESTAMP(3),
    CONSTRAINT "Message_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "Appointment" (
    "id" TEXT NOT NULL,
    "leadId" TEXT,
    "personId" TEXT NOT NULL,
    "ownerUserId" TEXT,
    "startsAt" TIMESTAMP(3) NOT NULL,
    "endsAt" TIMESTAMP(3),
    "status" TEXT NOT NULL DEFAULT 'scheduled',
    "location" TEXT,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "Appointment_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "Task" (
    "id" TEXT NOT NULL,
    "leadId" TEXT,
    "personId" TEXT,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "type" "TaskType" NOT NULL DEFAULT 'GENERAL',
    "priority" TEXT NOT NULL DEFAULT 'normal',
    "source" TEXT,
    "status" "TaskStatus" NOT NULL DEFAULT 'OPEN',
    "dueAt" TIMESTAMP(3),
    "completedAt" TIMESTAMP(3),
    "completionNote" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "createdByUserId" TEXT,
    "assignedUserId" TEXT,
    CONSTRAINT "Task_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "AgentDecision" (
    "id" TEXT NOT NULL,
    "leadId" TEXT NOT NULL,
    "conversationId" TEXT,
    "messageId" TEXT,
    "decidedByUserId" TEXT,
    "decisionType" TEXT NOT NULL,
    "rationale" TEXT,
    "payload" JSONB,
    "provider" TEXT,
    "classification" "ReplyClassification",
    "confidenceScore" DOUBLE PRECISION,
    "draftIntent" "AIDraftIntent",
    "appointmentStageRecommendation" "LeadStage",
    "ownershipRecommendation" "OwnershipState",
    "urgency" "AIDecisionUrgency",
    "channelRecommendation" "ConversationChannel",
    "suggestedDelayMinutes" INTEGER,
    "handoffRecommended" BOOLEAN NOT NULL DEFAULT false,
    "adaptedFromLearning" BOOLEAN NOT NULL DEFAULT false,
    "personalizationSummary" TEXT,
    "autoResponseEligible" BOOLEAN,
    "autoResponseReason" TEXT,
    "escalationReason" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "AgentDecision_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "AgentLearningProfile" (
    "id" TEXT NOT NULL,
    "agentProfileId" TEXT NOT NULL,
    "tonePreference" TEXT NOT NULL DEFAULT 'friendly_direct',
    "directnessScore" DOUBLE PRECISION NOT NULL DEFAULT 0.55,
    "brevityScore" DOUBLE PRECISION NOT NULL DEFAULT 0.55,
    "spanishPreferenceScore" DOUBLE PRECISION NOT NULL DEFAULT 0.25,
    "appointmentAskStyle" TEXT NOT NULL DEFAULT 'direct',
    "serviceMessageStyle" TEXT NOT NULL DEFAULT 'consultative',
    "miningMessageStyle" TEXT NOT NULL DEFAULT 'reactivation_light',
    "commandPreferenceSummary" JSONB,
    "workflowPreferenceSummary" JSONB,
    "adaptationSummary" TEXT,
    "learningStrength" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "lastLearnedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "AgentLearningProfile_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "AgentFeedbackEvent" (
    "id" TEXT NOT NULL,
    "agentProfileId" TEXT NOT NULL,
    "signalType" "PersonalizationSignalType" NOT NULL,
    "leadId" TEXT,
    "conversationId" TEXT,
    "messageId" TEXT,
    "decisionId" TEXT,
    "commandId" TEXT,
    "metadata" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "AgentFeedbackEvent_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "AutoResponseAudit" (
    "id" TEXT NOT NULL,
    "agentProfileId" TEXT NOT NULL,
    "leadId" TEXT NOT NULL,
    "conversationId" TEXT NOT NULL,
    "inboundMessageId" TEXT,
    "responseMessageId" TEXT,
    "decisionId" TEXT,
    "channel" "ConversationChannel" NOT NULL,
    "mode" "AutoResponseMode" NOT NULL,
    "status" "AutoResponseStatus" NOT NULL,
    "eligible" BOOLEAN NOT NULL DEFAULT false,
    "reason" TEXT,
    "guardrailReason" TEXT,
    "executed" BOOLEAN NOT NULL DEFAULT false,
    "deferredUntil" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "metadata" JSONB,
    CONSTRAINT "AutoResponseAudit_pkey" PRIMARY KEY ("id")
);

CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

CREATE UNIQUE INDEX "LoginThrottle_key_key" ON "LoginThrottle"("key");

CREATE UNIQUE INDEX "Lead_personId_key" ON "Lead"("personId");

CREATE UNIQUE INDEX "LeadSource_sourceSystem_sourceRecordId_key" ON "LeadSource"("sourceSystem", "sourceRecordId");

CREATE UNIQUE INDEX "SmartFilter_key_key" ON "SmartFilter"("key");

CREATE UNIQUE INDEX "WorkflowJobLog_dedupeKey_key" ON "WorkflowJobLog"("dedupeKey");

CREATE UNIQUE INDEX "AgentLearningProfile_agentProfileId_key" ON "AgentLearningProfile"("agentProfileId");

CREATE INDEX "AuthAuditEvent_userId_createdAt_idx" ON "AuthAuditEvent"("userId", "createdAt");

CREATE INDEX "AuthAuditEvent_email_createdAt_idx" ON "AuthAuditEvent"("email", "createdAt");

CREATE INDEX "AuthAuditEvent_action_createdAt_idx" ON "AuthAuditEvent"("action", "createdAt");

CREATE INDEX "LoginThrottle_scope_email_idx" ON "LoginThrottle"("scope", "email");

CREATE INDEX "LoginThrottle_scope_ipAddress_idx" ON "LoginThrottle"("scope", "ipAddress");

CREATE INDEX "LoginThrottle_blockedUntil_idx" ON "LoginThrottle"("blockedUntil");

CREATE INDEX "Person_emailNormalized_idx" ON "Person"("emailNormalized");

CREATE INDEX "Person_phoneNormalized_idx" ON "Person"("phoneNormalized");

CREATE INDEX "Person_fullName_postalCode_idx" ON "Person"("fullName", "postalCode");

CREATE INDEX "Lead_sourceSystem_stage_status_idx" ON "Lead"("sourceSystem", "stage", "status");

CREATE INDEX "Lead_automationStatus_nextFollowUpAt_idx" ON "Lead"("automationStatus", "nextFollowUpAt");

CREATE INDEX "Lead_callPriorityScore_updatedAt_idx" ON "Lead"("callPriorityScore", "updatedAt");

CREATE INDEX "Lead_ownerUserId_idx" ON "Lead"("ownerUserId");

CREATE INDEX "LeadSource_leadId_sourceSystem_idx" ON "LeadSource"("leadId", "sourceSystem");

CREATE INDEX "LeadSource_personId_sourceSystem_idx" ON "LeadSource"("personId", "sourceSystem");

CREATE INDEX "SmartFilter_agentProfileId_sortOrder_idx" ON "SmartFilter"("agentProfileId", "sortOrder");

CREATE INDEX "SmartFilter_listType_sortOrder_idx" ON "SmartFilter"("listType", "sortOrder");

CREATE INDEX "AgentCommand_commandKey_createdAt_idx" ON "AgentCommand"("commandKey", "createdAt");

CREATE INDEX "AgentCommand_leadId_createdAt_idx" ON "AgentCommand"("leadId", "createdAt");

CREATE INDEX "WorkflowJobLog_leadId_status_scheduledFor_idx" ON "WorkflowJobLog"("leadId", "status", "scheduledFor");

CREATE INDEX "WorkflowJobLog_jobType_status_scheduledFor_idx" ON "WorkflowJobLog"("jobType", "status", "scheduledFor");

CREATE INDEX "WorkflowJobLog_conversationId_idx" ON "WorkflowJobLog"("conversationId");

CREATE INDEX "WorkflowJobLog_appointmentId_idx" ON "WorkflowJobLog"("appointmentId");

CREATE INDEX "CaptureAudit_createdAt_idx" ON "CaptureAudit"("createdAt");

CREATE INDEX "CaptureAudit_leadId_createdAt_idx" ON "CaptureAudit"("leadId", "createdAt");

CREATE INDEX "CaptureAudit_sourceSystem_sourceRecordId_idx" ON "CaptureAudit"("sourceSystem", "sourceRecordId");

CREATE INDEX "Conversation_leadId_channel_idx" ON "Conversation"("leadId", "channel");

CREATE INDEX "Conversation_contactPhoneNormalized_channel_idx" ON "Conversation"("contactPhoneNormalized", "channel");

CREATE INDEX "Conversation_contactEmailNormalized_channel_idx" ON "Conversation"("contactEmailNormalized", "channel");

CREATE INDEX "Conversation_providerThreadId_channel_idx" ON "Conversation"("providerThreadId", "channel");

CREATE INDEX "Conversation_threadKey_channel_idx" ON "Conversation"("threadKey", "channel");

CREATE INDEX "Conversation_updatedAt_idx" ON "Conversation"("updatedAt");

CREATE INDEX "Message_conversationId_createdAt_idx" ON "Message"("conversationId", "createdAt");

CREATE INDEX "Message_externalId_idx" ON "Message"("externalId");

CREATE INDEX "Message_inReplyTo_idx" ON "Message"("inReplyTo");

CREATE INDEX "Message_status_createdAt_idx" ON "Message"("status", "createdAt");

CREATE INDEX "Task_status_dueAt_idx" ON "Task"("status", "dueAt");

CREATE INDEX "Task_leadId_type_status_idx" ON "Task"("leadId", "type", "status");

CREATE INDEX "AgentDecision_leadId_decisionType_createdAt_idx" ON "AgentDecision"("leadId", "decisionType", "createdAt");

CREATE INDEX "AgentDecision_conversationId_createdAt_idx" ON "AgentDecision"("conversationId", "createdAt");

CREATE INDEX "AgentDecision_messageId_idx" ON "AgentDecision"("messageId");

CREATE INDEX "AgentLearningProfile_learningStrength_updatedAt_idx" ON "AgentLearningProfile"("learningStrength", "updatedAt");

CREATE INDEX "AgentFeedbackEvent_signalType_createdAt_idx" ON "AgentFeedbackEvent"("signalType", "createdAt");

CREATE INDEX "AgentFeedbackEvent_agentProfileId_createdAt_idx" ON "AgentFeedbackEvent"("agentProfileId", "createdAt");

CREATE INDEX "AgentFeedbackEvent_leadId_createdAt_idx" ON "AgentFeedbackEvent"("leadId", "createdAt");

CREATE INDEX "AutoResponseAudit_conversationId_createdAt_idx" ON "AutoResponseAudit"("conversationId", "createdAt");

CREATE INDEX "AutoResponseAudit_leadId_createdAt_idx" ON "AutoResponseAudit"("leadId", "createdAt");

CREATE INDEX "AutoResponseAudit_status_createdAt_idx" ON "AutoResponseAudit"("status", "createdAt");

ALTER TABLE "AuthAuditEvent" ADD CONSTRAINT "AuthAuditEvent_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "LoginThrottle" ADD CONSTRAINT "LoginThrottle_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "Lead" ADD CONSTRAINT "Lead_personId_fkey" FOREIGN KEY ("personId") REFERENCES "Person"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "Lead" ADD CONSTRAINT "Lead_ownerUserId_fkey" FOREIGN KEY ("ownerUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "LeadSource" ADD CONSTRAINT "LeadSource_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES "Lead"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "LeadSource" ADD CONSTRAINT "LeadSource_personId_fkey" FOREIGN KEY ("personId") REFERENCES "Person"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "SmartFilter" ADD CONSTRAINT "SmartFilter_agentProfileId_fkey" FOREIGN KEY ("agentProfileId") REFERENCES "AgentProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "AgentCommand" ADD CONSTRAINT "AgentCommand_agentProfileId_fkey" FOREIGN KEY ("agentProfileId") REFERENCES "AgentProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "AgentCommand" ADD CONSTRAINT "AgentCommand_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES "Lead"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "AgentCommand" ADD CONSTRAINT "AgentCommand_actorUserId_fkey" FOREIGN KEY ("actorUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "WorkflowJobLog" ADD CONSTRAINT "WorkflowJobLog_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES "Lead"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "WorkflowJobLog" ADD CONSTRAINT "WorkflowJobLog_appointmentId_fkey" FOREIGN KEY ("appointmentId") REFERENCES "Appointment"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "WorkflowJobLog" ADD CONSTRAINT "WorkflowJobLog_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "Conversation"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "WorkflowJobLog" ADD CONSTRAINT "WorkflowJobLog_taskId_fkey" FOREIGN KEY ("taskId") REFERENCES "Task"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "CaptureAudit" ADD CONSTRAINT "CaptureAudit_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES "Lead"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "CaptureAudit" ADD CONSTRAINT "CaptureAudit_personId_fkey" FOREIGN KEY ("personId") REFERENCES "Person"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "CaptureAudit" ADD CONSTRAINT "CaptureAudit_leadSourceId_fkey" FOREIGN KEY ("leadSourceId") REFERENCES "LeadSource"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "Conversation" ADD CONSTRAINT "Conversation_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES "Lead"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "Conversation" ADD CONSTRAINT "Conversation_personId_fkey" FOREIGN KEY ("personId") REFERENCES "Person"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "Message" ADD CONSTRAINT "Message_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "Conversation"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "Appointment" ADD CONSTRAINT "Appointment_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES "Lead"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "Appointment" ADD CONSTRAINT "Appointment_personId_fkey" FOREIGN KEY ("personId") REFERENCES "Person"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "Appointment" ADD CONSTRAINT "Appointment_ownerUserId_fkey" FOREIGN KEY ("ownerUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "Task" ADD CONSTRAINT "Task_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES "Lead"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "Task" ADD CONSTRAINT "Task_personId_fkey" FOREIGN KEY ("personId") REFERENCES "Person"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "Task" ADD CONSTRAINT "Task_createdByUserId_fkey" FOREIGN KEY ("createdByUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "Task" ADD CONSTRAINT "Task_assignedUserId_fkey" FOREIGN KEY ("assignedUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "AgentDecision" ADD CONSTRAINT "AgentDecision_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES "Lead"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "AgentDecision" ADD CONSTRAINT "AgentDecision_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "Conversation"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "AgentDecision" ADD CONSTRAINT "AgentDecision_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES "Message"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "AgentDecision" ADD CONSTRAINT "AgentDecision_decidedByUserId_fkey" FOREIGN KEY ("decidedByUserId") REFERENCES "User"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "AgentLearningProfile" ADD CONSTRAINT "AgentLearningProfile_agentProfileId_fkey" FOREIGN KEY ("agentProfileId") REFERENCES "AgentProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "AgentFeedbackEvent" ADD CONSTRAINT "AgentFeedbackEvent_agentProfileId_fkey" FOREIGN KEY ("agentProfileId") REFERENCES "AgentProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "AgentFeedbackEvent" ADD CONSTRAINT "AgentFeedbackEvent_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES "Lead"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "AgentFeedbackEvent" ADD CONSTRAINT "AgentFeedbackEvent_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "Conversation"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "AgentFeedbackEvent" ADD CONSTRAINT "AgentFeedbackEvent_messageId_fkey" FOREIGN KEY ("messageId") REFERENCES "Message"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "AgentFeedbackEvent" ADD CONSTRAINT "AgentFeedbackEvent_decisionId_fkey" FOREIGN KEY ("decisionId") REFERENCES "AgentDecision"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "AgentFeedbackEvent" ADD CONSTRAINT "AgentFeedbackEvent_commandId_fkey" FOREIGN KEY ("commandId") REFERENCES "AgentCommand"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "AutoResponseAudit" ADD CONSTRAINT "AutoResponseAudit_agentProfileId_fkey" FOREIGN KEY ("agentProfileId") REFERENCES "AgentProfile"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "AutoResponseAudit" ADD CONSTRAINT "AutoResponseAudit_leadId_fkey" FOREIGN KEY ("leadId") REFERENCES "Lead"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "AutoResponseAudit" ADD CONSTRAINT "AutoResponseAudit_conversationId_fkey" FOREIGN KEY ("conversationId") REFERENCES "Conversation"("id") ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE "AutoResponseAudit" ADD CONSTRAINT "AutoResponseAudit_inboundMessageId_fkey" FOREIGN KEY ("inboundMessageId") REFERENCES "Message"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "AutoResponseAudit" ADD CONSTRAINT "AutoResponseAudit_responseMessageId_fkey" FOREIGN KEY ("responseMessageId") REFERENCES "Message"("id") ON DELETE SET NULL ON UPDATE CASCADE;

ALTER TABLE "AutoResponseAudit" ADD CONSTRAINT "AutoResponseAudit_decisionId_fkey" FOREIGN KEY ("decisionId") REFERENCES "AgentDecision"("id") ON DELETE SET NULL ON UPDATE CASCADE;
