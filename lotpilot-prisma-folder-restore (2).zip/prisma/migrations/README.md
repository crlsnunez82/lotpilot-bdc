Production uses committed Prisma migrations in subdirectories under `prisma/migrations/`.

This repository now includes a baseline migration:

- `prisma/migrations/20260512_enterprise_baseline/migration.sql`

Notes:
- The baseline SQL was generated manually from `prisma/schema.prisma` in an offline environment.
- Before first production deploy, apply it in a staging database and verify Prisma can report a clean migration status.
- Production startup is already configured to use `npx prisma migrate deploy`.
